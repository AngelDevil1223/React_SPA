export const contentdata = [
	{
		question : "Why should I submit an application?",
		answer : "Try camming solo. If you would like to have a bigger room with more tips in a shorter time, we can make that happen.",
	},
	{
		question : "Is there a fee?",
		answer : "We take no fee. All tips earned are split pro rata among the models.",
	},
	{
		question : "Is this safe?",
		answer : "We will ensure that the models submit valid sti testing before a stream. We will also ensure that models are safe and provide additional desired support.",
	},
];
