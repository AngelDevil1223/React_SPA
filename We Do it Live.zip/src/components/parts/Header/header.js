import React, { Component } from 'react';
import { Link } from 'react-router';
import "./header.css";

class Header extends Component {

  render() {
    return (
      	<div className="header">
      		<div className="header_h">
      			WE DO IT LIVE.
      		</div>
      		<div className="header_p">
      			Live sex gets more viewers and earns
      		</div>
      		<div className="h_u_p">
            more tips than solo streams. We help cam performers and other adult performers set up professional, talented, and safe co-performers for livestreams. Porn is an old business--we do it live.
      		</div>
      	</div>
    );
  }
}

export default Header;